﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using Models;
namespace Dongdongdongman.Models
{
    public class Comic_Home
    {
        public IEnumerable<Comic> Nc;
        public IEnumerable<Comic> Te;
       
    }
}